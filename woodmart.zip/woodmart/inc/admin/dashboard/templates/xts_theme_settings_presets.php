<?php

XTS\Presets::get_instance()->output_ui();
